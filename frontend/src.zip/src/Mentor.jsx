import { useState } from "react";
import { request, jsonOptions, skillList, SimpleForm } from "./helpers.jsx";

export default function Mentor({ token }) {
    const [scores, setScores] = useState(null);
    const [error, setError] = useState("");

    async function loadScores() {
        setError("");
        try {
            const data = await request("/scores", {}, token);
            setScores(Array.isArray(data) ? data : data.scores || []);
        } catch (err) {
            setError(err.message);
        }
    }

    return (
        <div className="page">
            <SimpleForm
                title="Upload Modules"
                buttonText="Upload"
                fields={[
                    { name: "title", label: "Module title" },
                    { name: "skills", label: "Skills (comma separated)" },
                ]}
                onSubmit={(v) =>
                    request(
                        "/modules",
                        jsonOptions("POST", { title: v.title, skills_taught: skillList(v.skills) }),
                        token
                    )
                }
            />

            <SimpleForm
                title="Edit Modules"
                buttonText="Save changes"
                fields={[
                    { name: "id", label: "Module ID" },
                    { name: "title", label: "New title" },
                    { name: "skills", label: "New skills (comma separated)" },
                ]}
                onSubmit={(v) =>
                    request(
                        "/modules/" + v.id,
                        jsonOptions("PUT", { title: v.title, skills: skillList(v.skills) }),
                        token
                    )
                }
            />

            <div className="panel">
                <h3>Check Student Scores</h3>
                <button onClick={loadScores}>Load scores</button>
                {error && <p className="message error">{error}</p>}
                {scores && (
                    <table>
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            {scores.map((s, i) => (
                                <tr key={i}>
                                    <td>{s.student || s.name || s.email}</td>
                                    <td>{s.score}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}