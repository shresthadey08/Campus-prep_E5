import { useState } from "react";
import Auth from "./Auth.jsx";
import Student from "./Student.jsx";
import Mentor from "./Mentor.jsx";
import Admin from "./Admin.jsx";

export default function App() {
  const [user, setUser] = useState(null); // { role, token }
  const [authMode, setAuthMode] = useState("login"); // "login" | "register"

  // role comes from the backend login response, never from the user
  function handleAuth(data) {
    setUser({ role: data.role, token: data.token });
  }

  function goLogin(e) {
    e.preventDefault();
    setAuthMode("login");
  }

  function goRegister(e) {
    e.preventDefault();
    setAuthMode("register");
  }

  function logout(e) {
    e.preventDefault();
    setUser(null);
    setAuthMode("login");
  }

  let content;
  if (user) {
    if (user.role === "student") content = <Student token={user.token} />;
    else if (user.role === "mentor") content = <Mentor token={user.token} />;
    else if (user.role === "admin") content = <Admin token={user.token} />;
    else content = <div className="page"><p>Unknown account role.</p></div>;
  }  else {
  content = (
    <div className="auth-page">
      <Auth
        mode={authMode}
        onAuth={handleAuth}
        onSwitch={setAuthMode}
      />
    </div>
  );
}

  return (
    <div>
      <nav className="navbar">
        <span className="logo">PlacementHub</span>
        <div className="nav-links">
          {user ? (
            <>
              <span className="nav-role">{user.role}</span>
              <a href="#" onClick={logout}>Logout</a>
            </>
          ) : (
            <>
              <a href="#" onClick={goLogin}>Login</a>
              <a href="#" className="nav-register" onClick={goRegister}>Register</a>
            </>
          )}
        </div>
      </nav>
      {content}
    </div>
  );
}