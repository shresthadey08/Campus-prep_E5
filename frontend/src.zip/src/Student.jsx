import { useState } from "react";
import { request } from "./helpers.jsx";

export default function Student({ token }) {
    const [file, setFile] = useState(null);
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    async function submitCv(e) {
        e.preventDefault();
        if (!file) return setError("Please choose a CV file.");
        setError("");
        setLoading(true);
        try {
            const formData = new FormData();
            formData.append("file", file);
            const data = await request(
                "/upload-cv",
                { method: "POST", body: formData },
                token
            );
            setResult(data);
        } catch (err) {
            setError(err.message);
        }
        setLoading(false);
    }

    async function deleteCv() {
        setError("");
        try {
            await request("/cv/" + result.cv_id, { method: "DELETE" }, token);
            setResult(null);
            setFile(null);
        } catch (err) {
            setError(err.message);
        }
    }

    // Edit CV = go back to the upload step and submit a new file
    function editCv() {
        setResult(null);
        setFile(null);
    }

    // ---------- Step 1: upload ----------
    if (!result) {
        return (
            <div className="page">
                <form className="panel upload-box" onSubmit={submitCv}>
                    <h3>Upload CV</h3>
                    <p className="hint">PDF or DOCX</p>
                    <input
                        type="file"
                        accept=".pdf,.docx"
                        onChange={(e) => setFile(e.target.files[0])}
                    />
                    <button type="submit" disabled={loading}>
                        {loading ? "Submitting..." : "Submit CV"}
                    </button>
                    {error && <p className="message error">{error}</p>}
                </form>
            </div>
        );
    }

    // ---------- Step 2: results (all values come from the backend) ----------
    const jobs = result.recommended_jobs || [];
    const skills = result.missing_skills || [];
    const modules = result.recommended_modules || [];

    const jobTitle = (j) => j.title || j.job_title || j.name || "";
    const jobCompany = (j) => j.company || j.company_name || "";
    const jobScore = (j) => Number(j.match ?? j.match_percentage ?? j.score ?? 0);

    const top = jobs.length
        ? jobs.reduce((a, b) => (jobScore(b) > jobScore(a) ? b : a))
        : null;

    return (
        <div className="page">
            <div className="summary">
                <div className="panel">
                    <span className="label">Overall CV match</span>
                    <strong className="big">{result.overall_match}%</strong>
                </div>

                <div className="panel">
                    <span className="label">Recommended jobs</span>
                    <strong className="big">{jobs.length}</strong>
                </div>

                <div className="panel">
                    <span className="label">Top match</span>
                    <strong className="big">{top ? jobScore(top) + "%" : "-"}</strong>
                    {top && (
                        <span className="label">
                            {jobTitle(top)}
                            {jobCompany(top) && " · " + jobCompany(top)}
                        </span>
                    )}
                </div>
            </div>

            <div className="results">
                <div className="panel">
                    <h3>Job match ranking</h3>
                    {jobs.map((j, i) => (
                        <div className="job-row" key={i}>
                            <span className="job-name">{jobTitle(j)}</span>
                            <div className="bar">
                                <div
                                    className="bar-fill"
                                    style={{ width: jobScore(j) + "%" }}
                                />
                            </div>
                            <span className="job-score">{jobScore(j)}%</span>
                        </div>
                    ))}
                </div>

                <div className="side">
                    <div className="panel">
                        <h3>Skills to develop</h3>
                        <div className="chips">
                            {skills.map((s, i) => (
                                <span className="chip" key={i}>
                                    {s}
                                </span>
                            ))}
                        </div>
                    </div>

                    <div className="panel">
                        <h3>Recommended learning</h3>
                        {modules.map((m, i) => (
                            <div className="module" key={i}>
                                <strong>{m.title || m.name}</strong>
                                <span className="label">
                                    {[
                                        m.mentor || m.mentor_name,
                                        Array.isArray(m.skills_taught)
                                            ? m.skills_taught.join(", ")
                                            : Array.isArray(m.skills)
                                              ? m.skills.join(", ")
                                              : m.skills,
                                    ]
                                        .filter(Boolean)
                                        .join(" · ")}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {result.extracted_text_preview && (
                <div className="panel">
                    <h3>CV preview</h3>
                    <p className="preview">{result.extracted_text_preview}</p>
                </div>
            )}

            <div className="actions">
                <button onClick={editCv}>Edit CV</button>
                <button onClick={deleteCv}>Delete CV</button>
            </div>
            {error && <p className="message error">{error}</p>}
        </div>
    );
}