import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./App.css";

import "./styles/base.css";
import "./styles/navbar.css";
import "./styles/layout.css";
import "./styles/forms.css";
import "./styles/auth.css";
import "./styles/student.css";
import "./styles/mentor.css";
import "./styles/responsive.css";

ReactDOM.createRoot(document.getElementById("root")).render(<App />);