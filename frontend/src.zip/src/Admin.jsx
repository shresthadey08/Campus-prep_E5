import { request, jsonOptions, skillList, SimpleForm } from "./helpers.jsx";

export default function Admin({ token }) {
    return (
        <div className="page">
            <SimpleForm
                title="Add Company"
                buttonText="Add company"
                fields={[{ name: "name", label: "Company name" }]}
                onSubmit={(v) =>
                    request("/companies", jsonOptions("POST", { name: v.name }), token)
                }
            />

            <SimpleForm
                title="Add Job"
                buttonText="Add job"
                fields={[
                    { name: "title", label: "Job title" },
                    { name: "company", label: "Company" },
                    { name: "skills", label: "Required skills (comma separated)" },
                ]}
                onSubmit={(v) =>
                    request(
                        "/jobs",
                        jsonOptions("POST", {
                            title: v.title,
                            company: v.company,
                            required_skills: skillList(v.skills),
                        }),
                        token
                    )
                }
            />

            <SimpleForm
                title="Edit Job"
                buttonText="Save changes"
                fields={[
                    { name: "id", label: "Job ID" },
                    { name: "title", label: "New title" },
                    { name: "skills", label: "New required skills (comma separated)" },
                ]}
                onSubmit={(v) =>
                    request(
                        "/jobs/" + v.id,
                        jsonOptions("PUT", { title: v.title, skills: skillList(v.skills) }),
                        token
                    )
                }
            />

            <SimpleForm
                title="Delete Job"
                buttonText="Delete job"
                fields={[{ name: "id", label: "Job ID" }]}
                onSubmit={(v) => request("/jobs/" + v.id, { method: "DELETE" }, token)}
            />

            <SimpleForm
                title="Manage Company Openings"
                buttonText="Update openings"
                fields={[
                    { name: "company", label: "Company" },
                    { name: "openings", label: "Number of openings", type: "number" },
                ]}
                onSubmit={(v) =>
                    request(
                        "/openings",
                        jsonOptions("PUT", {
                            company: v.company,
                            openings: Number(v.openings),
                        }),
                        token
                    )
                }
            />
        </div>
    );
}