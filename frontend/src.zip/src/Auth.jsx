import { useState } from "react";
import { request, jsonOptions } from "./helpers.jsx";

export default function Auth({ mode, onAuth, onSwitch }) {
    const [form, setForm] = useState({ name: "", email: "", password: "", role: "student" });
    const [error, setError] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const isLogin = mode === "login";

    async function handleSubmit(e) {
        e.preventDefault();
        setError("");
        try {
            // login sends only email + password; register also sends the chosen role
            const body = isLogin
                ? { email: form.email, password: form.password }
                : form;
            const data = await request(
                isLogin ? "/login" : "/register",
                jsonOptions("POST", body)
            );
            // after login, the role used by the app comes from the backend response
            if (isLogin) onAuth(data);
            else onSwitch("login");
        } catch (err) {
            setError(err.message);
        }
    }

    function switchMode(e) {
        e.preventDefault();
        onSwitch(isLogin ? "register" : "login");
    }

    return (
        <form className="auth-box" onSubmit={handleSubmit}>
            <h2>{isLogin ? "Login" : "Register"}</h2>

            {!isLogin && (
                <div className="field">
                    <label>Name</label>
                    <input
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                    />
                </div>
            )}

            <div className="field">
                <label>Email</label>
                <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    required
                />
            </div>

            <div className="field">
                <label>Password</label>
                <div className="password-wrap">
                    <input
                        type={showPassword ? "text" : "password"}
                        value={form.password}
                        onChange={(e) => setForm({ ...form, password: e.target.value })}
                        required
                    />
                    <button
                        type="button"
                        className="password-toggle"
                        onClick={() => setShowPassword(!showPassword)}
                        aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                        {showPassword ? (
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                                <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                                <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24" />
                                <line x1="1" y1="1" x2="23" y2="23" />
                            </svg>
                        ) : (
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                <circle cx="12" cy="12" r="3" />
                            </svg>
                        )}
                    </button>
                </div>
            </div>

            {!isLogin && (
                <div className="field">
                    <label>Role</label>
                    <select
                        value={form.role}
                        onChange={(e) => setForm({ ...form, role: e.target.value })}
                        style={{
                            width: "100%",
                            padding: "9px 10px",
                            fontSize: "15px",
                            border: "1px solid #ccc",
                            borderRadius: "6px",
                            background: "#fff",
                        }}
                        required
                    >
                        <option value="student">Student</option>
                        <option value="mentor">Mentor</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
            )}

            <button type="submit">{isLogin ? "Login" : "Register"}</button>
            {error && <p className="message error">{error}</p>}

            <p className="switch">
                {isLogin ? "No account? " : "Already registered? "}
                <a href="#" onClick={switchMode}>{isLogin ? "Register" : "Login"}</a>
            </p>
        </form>
    );
}